import React, { useState } from 'react';
import { Game, GamingSystem, GraphicsSettings, CheatCode } from './types';
import { INITIAL_GAMES, INITIAL_CHEATS } from './data/mockGames';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { GameLibrary } from './components/GameLibrary';
import { EmulatorScreen } from './components/EmulatorScreen';
import { IsoImporter } from './components/IsoImporter';
import { GraphicsSettingsModal } from './components/GraphicsSettingsModal';
import { ControllerSettingsModal } from './components/ControllerSettingsModal';
import { CheatsModal } from './components/CheatsModal';
import { AboutModal } from './components/AboutModal';
import { Sparkles, Gamepad2, X, Play, Star, HardDrive, Clock } from 'lucide-react';

export default function App() {
  const [games, setGames] = useState<Game[]>(INITIAL_GAMES);
  const [cheats, setCheats] = useState<CheatCode[]>(INITIAL_CHEATS);
  const [graphics, setGraphics] = useState<GraphicsSettings>({
    resolutionScale: '4x (4K Ultra HD)',
    textureFiltering: 'xBRZ High Quality',
    shaderEffect: 'HDR Bloom & Neon',
    fpsLimit: '120 FPS High Refresh',
    antiAliasing: 'MSAA 4x',
    anisotropicFiltering: '16x',
    hardwareTransform: true,
    softwareSkinning: true,
    lazyTextureCaching: true,
    mipmapping: true,
    audioReverb: true
  });

  const [activeTab, setActiveTab] = useState<string>('library');
  const [selectedSystem, setSelectedSystem] = useState<GamingSystem | 'ALL' | 'FAVORITES'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeDevice, setActiveDevice] = useState<'android' | 'windows' | 'tablet'>('android');

  const [playingGame, setPlayingGame] = useState<Game | null>(null);
  const [selectedGameDetails, setSelectedGameDetails] = useState<Game | null>(null);
  const [showImporter, setShowImporter] = useState<boolean>(false);
  const [showGraphicsModal, setShowGraphicsModal] = useState<boolean>(false);
  const [showControllerModal, setShowControllerModal] = useState<boolean>(false);
  const [showCheatsModal, setShowCheatsModal] = useState<boolean>(false);
  const [showAboutModal, setShowAboutModal] = useState<boolean>(false);

  // Handlers
  const handleToggleFavorite = (gameId: string) => {
    setGames(prev => prev.map(g => g.id === gameId ? { ...g, isFavorite: !g.isFavorite } : g));
  };

  const handleAddGame = (newGame: Game) => {
    setGames(prev => [newGame, ...prev]);
  };

  const handleToggleCheat = (cheatId: string) => {
    setCheats(prev => prev.map(c => c.id === cheatId ? { ...c, enabled: !c.enabled } : c));
  };

  const handleAddCheat = (newCheat: CheatCode) => {
    setCheats(prev => [newCheat, ...prev]);
  };

  const favoriteCount = games.filter(g => g.isFavorite).length;

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-zinc-950">
      
      {/* Top Navbar */}
      <Navbar
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onOpenSettings={() => setShowGraphicsModal(true)}
        onOpenController={() => setShowControllerModal(true)}
        onOpenAbout={() => setShowAboutModal(true)}
        activeDevice={activeDevice}
        setActiveDevice={setActiveDevice}
      />

      {/* Main Body */}
      <div className="flex-grow flex flex-col lg:flex-row">
        
        {/* Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          selectedSystem={selectedSystem}
          setSelectedSystem={setSelectedSystem}
          gameCount={games.length}
          favoriteCount={favoriteCount}
          onOpenImporter={() => setShowImporter(true)}
        />

        {/* Content Area */}
        <main className="flex-grow p-4 lg:p-8 overflow-y-auto">
          
          {activeTab === 'library' && (
            <GameLibrary
              games={games}
              selectedSystem={selectedSystem}
              searchQuery={searchQuery}
              onPlay={(game) => setPlayingGame(game)}
              onToggleFavorite={handleToggleFavorite}
              onOpenDetails={(game) => setSelectedGameDetails(game)}
              onOpenImporter={() => setShowImporter(true)}
            />
          )}

          {activeTab === 'graphics' && (
            <div className="max-w-3xl mx-auto space-y-6">
              <div className="bg-zinc-900 border border-purple-500/30 p-6 rounded-3xl space-y-6">
                <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                  <div>
                    <h2 className="text-xl font-bold text-zinc-100">4K Graphics Engine Configuration</h2>
                    <p className="text-xs text-zinc-400">Superior rendering performance designed by Adetunbi Emmanuel</p>
                  </div>
                  <span className="px-3 py-1 bg-purple-500/20 border border-purple-500/50 text-purple-300 font-mono text-xs rounded-full">
                    Active Preset: Ultra 4K
                  </span>
                </div>

                {/* Quick controls */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-zinc-950 rounded-2xl border border-zinc-800">
                    <div>
                      <h4 className="text-sm font-bold text-cyan-400">Resolution Multiplier</h4>
                      <p className="text-xs text-zinc-400">Current: {graphics.resolutionScale}</p>
                    </div>
                    <button
                      onClick={() => setShowGraphicsModal(true)}
                      className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-zinc-950 font-bold rounded-xl text-xs transition"
                    >
                      Change Settings
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-zinc-950 rounded-2xl border border-zinc-800">
                    <div>
                      <h4 className="text-sm font-bold text-purple-400">Shader & CRT Post-Processing</h4>
                      <p className="text-xs text-zinc-400">Current: {graphics.shaderEffect}</p>
                    </div>
                    <button
                      onClick={() => setShowGraphicsModal(true)}
                      className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs transition"
                    >
                      Configure Shaders
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'controller' && (
            <div className="max-w-3xl mx-auto">
              <div className="bg-zinc-900 border border-cyan-500/30 p-6 rounded-3xl space-y-6">
                <h2 className="text-xl font-bold text-zinc-100">Controller & Touch Gamepad Settings</h2>
                <p className="text-xs text-zinc-400">Manage touch overlay sensitivity and physical Bluetooth/USB gamepads for Android, Windows, and Tablets.</p>
                <button
                  onClick={() => setShowControllerModal(true)}
                  className="px-6 py-3 bg-cyan-500 hover:bg-cyan-400 text-zinc-950 font-bold rounded-xl text-xs transition shadow-lg shadow-cyan-500/20"
                >
                  Open Gamepad Manager
                </button>
              </div>
            </div>
          )}

          {activeTab === 'cheats' && (
            <div className="max-w-3xl mx-auto">
              <div className="bg-zinc-900 border border-purple-500/30 p-6 rounded-3xl space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-bold text-zinc-100">Cheat Codes Manager</h2>
                    <p className="text-xs text-zinc-400">CWCheat & Action Replay engine</p>
                  </div>
                  <button
                    onClick={() => setShowCheatsModal(true)}
                    className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs transition"
                  >
                    Manage Cheats
                  </button>
                </div>
              </div>
            </div>
          )}

        </main>
      </div>

      {/* Modals & Emulator Screens */}
      {playingGame && (
        <EmulatorScreen
          game={playingGame}
          graphics={graphics}
          onClose={() => setPlayingGame(null)}
          onOpenCheats={() => setShowCheatsModal(true)}
          onOpenGraphics={() => setShowGraphicsModal(true)}
        />
      )}

      {showImporter && (
        <IsoImporter
          onClose={() => setShowImporter(false)}
          onAddGame={handleAddGame}
        />
      )}

      {showGraphicsModal && (
        <GraphicsSettingsModal
          graphics={graphics}
          setGraphics={setGraphics}
          onClose={() => setShowGraphicsModal(false)}
        />
      )}

      {showControllerModal && (
        <ControllerSettingsModal
          onClose={() => setShowControllerModal(false)}
        />
      )}

      {showCheatsModal && (
        <CheatsModal
          cheats={cheats}
          onToggleCheat={handleToggleCheat}
          onAddCheat={handleAddCheat}
          onClose={() => setShowCheatsModal(false)}
        />
      )}

      {showAboutModal && (
        <AboutModal
          onClose={() => setShowAboutModal(false)}
        />
      )}

      {/* Game Details Modal */}
      {selectedGameDetails && (
        <div className="fixed inset-0 z-50 bg-zinc-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-cyan-500/30 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col">
            <div className="relative aspect-[16/9] bg-zinc-950">
              <img
                src={selectedGameDetails.bannerUrl}
                alt={selectedGameDetails.title}
                className="w-full h-full object-cover opacity-80"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-transparent to-transparent"></div>
              <button
                onClick={() => setSelectedGameDetails(null)}
                className="absolute top-4 right-4 p-2 bg-zinc-950/80 hover:bg-zinc-900 text-zinc-200 rounded-full transition"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="absolute bottom-4 left-6">
                <span className="px-3 py-1 bg-cyan-500/20 border border-cyan-500/50 text-cyan-300 font-mono text-xs font-bold rounded-lg shadow">
                  {selectedGameDetails.system}
                </span>
                <h2 className="text-2xl md:text-3xl font-extrabold text-zinc-100 mt-2">
                  {selectedGameDetails.title}
                </h2>
              </div>
            </div>

            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between text-xs text-zinc-400 font-mono border-b border-zinc-800 pb-3">
                <span>Genre: <strong className="text-zinc-200">{selectedGameDetails.genre}</strong></span>
                <span>Region: <strong className="text-zinc-200">{selectedGameDetails.region}</strong></span>
                <span>File Size: <strong className="text-cyan-400">{selectedGameDetails.fileSize}</strong></span>
              </div>

              <p className="text-sm text-zinc-300 leading-relaxed">
                {selectedGameDetails.description}
              </p>

              <div className="flex items-center justify-end gap-3 pt-4">
                <button
                  onClick={() => setSelectedGameDetails(null)}
                  className="px-5 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold rounded-xl text-xs transition"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    const gameToPlay = selectedGameDetails;
                    setSelectedGameDetails(null);
                    setPlayingGame(gameToPlay);
                  }}
                  className="px-6 py-2.5 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-zinc-950 font-extrabold rounded-xl text-xs shadow-lg shadow-cyan-500/25 flex items-center gap-2 transition"
                >
                  <Play className="w-4 h-4 fill-zinc-950" /> Launch in 4K
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
