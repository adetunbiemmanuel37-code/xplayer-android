export type GamingSystem = 'PSP' | 'PS2' | 'PS1' | 'GameCube' | 'N64' | 'GBA' | 'Arcade';

export interface Game {
  id: string;
  title: string;
  system: GamingSystem;
  coverUrl: string;
  bannerUrl: string;
  fileSize: string;
  region: 'USA' | 'EUR' | 'JPN';
  rating: number;
  playTimeMinutes: number;
  lastPlayed?: string;
  description: string;
  genre: string;
  releaseYear: number;
  isFavorite: boolean;
  isCustom?: boolean;
  isoFileName?: string;
}

export interface GraphicsSettings {
  resolutionScale: '1x (Native)' | '2x (1080p)' | '4x (4K Ultra HD)' | '8x (Extreme 4K+)';
  textureFiltering: 'Nearest' | 'Linear' | 'xBRZ High Quality' | 'Anisotropic 16x';
  shaderEffect: 'None' | 'CRT Scanlines' | 'HDR Bloom & Neon' | 'Cel-Shaded' | 'Retro CRT Curved';
  fpsLimit: '60 FPS (Standard)' | '120 FPS High Refresh' | 'Uncapped (Ultra)';
  antiAliasing: 'Off' | 'FXAA' | 'MSAA 4x' | 'MSAA 8x';
  anisotropicFiltering: 'Off' | '2x' | '4x' | '8x' | '16x';
  hardwareTransform: boolean;
  softwareSkinning: boolean;
  lazyTextureCaching: boolean;
  mipmapping: boolean;
  audioReverb: boolean;
}

export interface ControllerMapping {
  up: string;
  down: string;
  left: string;
  right: string;
  cross: string; // A
  circle: string; // B
  square: string; // X
  triangle: string; // Y
  l1: string;
  r1: string;
  l2: string;
  r2: string;
  start: string;
  select: string;
}

export interface CheatCode {
  id: string;
  gameId: string;
  title: string;
  code: string;
  enabled: boolean;
  description: string;
}

export interface SaveState {
  id: string;
  gameId: string;
  slotNumber: number;
  timestamp: string;
  thumbnailUrl: string;
  playtime: string;
}
