import React from 'react';
import { X, Sparkles, Gamepad2, ShieldCheck, Zap, Trophy, Heart } from 'lucide-react';

interface AboutModalProps {
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-zinc-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-zinc-900 border border-cyan-500/30 rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="px-6 py-4 bg-zinc-950 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Gamepad2 className="w-6 h-6 text-cyan-400" />
            <div>
              <h2 className="text-base font-bold text-zinc-100">About XPlayer 4K Ultra</h2>
              <p className="text-[11px] text-cyan-400 font-mono">Creator: Adetunbi Emmanuel</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 overflow-y-auto">
          
          {/* Creator Greeting */}
          <div className="bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-blue-500/10 border border-cyan-500/30 rounded-2xl p-5 space-y-3">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 bg-cyan-500 text-zinc-950 font-extrabold text-xs rounded-full uppercase tracking-wider">
                Official Release
              </span>
              <span className="text-xs text-zinc-400 font-mono">Version 3.8 Pro Gold Edition</span>
            </div>
            <h3 className="text-lg font-black text-zinc-100">
              Created with excellence by <span className="text-cyan-400">Adetunbi Emmanuel</span>
            </h3>
            <p className="text-xs md:text-sm text-zinc-300 leading-relaxed">
              XPlayer was built to surpass <strong className="text-amber-400">PPSSPP Gold</strong> by delivering pristine 4K graphics upscaling, zero latency touch and physical controller support, lightning-fast ISO loading, and a gorgeous multi-platform experience for Android, Windows, and Tablets.
            </p>
          </div>

          {/* Why Better than PPSSPP Gold */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-purple-400 flex items-center gap-1.5">
              <Trophy className="w-4 h-4" /> Why XPlayer Beats PPSSPP Gold
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="bg-zinc-950 border border-zinc-800 p-3.5 rounded-xl space-y-1">
                <h5 className="text-xs font-bold text-cyan-400 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" /> Native 4K Upscaling
                </h5>
                <p className="text-[11px] text-zinc-400">Advanced texture filtering (xBRZ) and HDR bloom shaders for ultra-crisp visuals.</p>
              </div>

              <div className="bg-zinc-950 border border-zinc-800 p-3.5 rounded-xl space-y-1">
                <h5 className="text-xs font-bold text-cyan-400 flex items-center gap-1">
                  <Gamepad2 className="w-3.5 h-3.5" /> Universal Multi-System
                </h5>
                <p className="text-[11px] text-zinc-400">Not just PSP! Play PSP, PS2, PS1, GameCube, N64, GBA, and Arcade ROMs in one app.</p>
              </div>

              <div className="bg-zinc-950 border border-zinc-800 p-3.5 rounded-xl space-y-1">
                <h5 className="text-xs font-bold text-cyan-400 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> Multi-Platform Sync
                </h5>
                <p className="text-[11px] text-zinc-400">Seamlessly optimized for Android phones, Windows PCs, and touch tablets.</p>
              </div>

              <div className="bg-zinc-950 border border-zinc-800 p-3.5 rounded-xl space-y-1">
                <h5 className="text-xs font-bold text-cyan-400 flex items-center gap-1">
                  <Zap className="w-3.5 h-3.5" /> Built-In Cheat Engine
                </h5>
                <p className="text-[11px] text-zinc-400">Instantly toggle God Mode, infinite health, and max currency without external tools.</p>
              </div>
            </div>
          </div>

          <div className="text-center pt-2">
            <p className="text-xs text-zinc-500 font-mono">
              © 2026 XPlayer Project. Developed by Adetunbi Emmanuel. All rights reserved.
            </p>
          </div>

        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-zinc-950 border-t border-zinc-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-purple-600 text-zinc-950 font-bold rounded-xl text-xs shadow-lg transition"
          >
            Got It, Let's Play!
          </button>
        </div>

      </div>
    </div>
  );
};
