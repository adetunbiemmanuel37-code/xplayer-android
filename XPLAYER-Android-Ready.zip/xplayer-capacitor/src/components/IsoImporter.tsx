import React, { useState } from 'react';
import { X, Upload, HardDrive, Sparkles, CheckCircle, FileCode } from 'lucide-react';
import { Game, GamingSystem } from '../types';

interface IsoImporterProps {
  onClose: () => void;
  onAddGame: (game: Game) => void;
}

export const IsoImporter: React.FC<IsoImporterProps> = ({ onClose, onAddGame }) => {
  const [title, setTitle] = useState('');
  const [system, setSystem] = useState<GamingSystem>('PSP');
  const [region, setRegion] = useState<'USA' | 'EUR' | 'JPN'>('USA');
  const [fileName, setFileName] = useState('');
  const [fileSize, setFileSize] = useState('1.2 GB');
  const [genre, setGenre] = useState('Action RPG');
  const [description, setDescription] = useState('');
  const [imported, setImported] = useState(false);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setFileName(file.name);
      // Auto estimate size
      const sizeMb = (file.size / (1024 * 1024)).toFixed(1);
      setFileSize(`${sizeMb} MB`);
      // Auto detect title from filename without extension
      const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[_]/g, ' ');
      setTitle(cleanName);

      // Auto detect system from extension
      const ext = file.name.split('.').pop()?.toLowerCase();
      if (ext === 'gba') setSystem('GBA');
      else if (ext === 'iso' || ext === 'cso') setSystem('PSP');
      else if (ext === 'bin' || ext === 'cue') setSystem('PS1');
      else if (ext === 'z64' || ext === 'n64') setSystem('N64');
    }
  };

  const handleImportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const newGame: Game = {
      id: `custom-${Date.now()}`,
      title: title.trim(),
      system,
      coverUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=800',
      bannerUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=1600',
      fileSize,
      region,
      rating: 4.8,
      playTimeMinutes: 0,
      description: description.trim() || `Custom imported ISO game for ${system} running with XPlayer 4K engine.`,
      genre,
      releaseYear: 2024,
      isFavorite: false,
      isCustom: true,
      isoFileName: fileName || 'game_rom.iso'
    };

    onAddGame(newGame);
    setImported(true);
    setTimeout(() => {
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-zinc-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-zinc-900 border border-cyan-500/30 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl">
        
        {/* Header */}
        <div className="px-6 py-4 bg-zinc-950 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base font-bold text-zinc-100">Import ISO / ROM Game File</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {imported ? (
          <div className="p-10 text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-500/20 border border-emerald-500/50 rounded-full flex items-center justify-center mx-auto text-emerald-400">
              <CheckCircle className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-zinc-100">ISO Imported Successfully!</h3>
            <p className="text-sm text-zinc-400">Added to your XPlayer 4K Library.</p>
          </div>
        ) : (
          <form onSubmit={handleImportSubmit} className="p-6 space-y-4">
            
            {/* File Dropzone */}
            <div className="border-2 border-dashed border-cyan-500/30 hover:border-cyan-500/60 rounded-2xl p-6 text-center bg-zinc-950/40 relative cursor-pointer group">
              <input
                type="file"
                accept=".iso,.cso,.bin,.cue,.gba,.z64,.n64,.zip"
                onChange={handleFileSelect}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
              <div className="flex flex-col items-center gap-2">
                <div className="w-12 h-12 bg-cyan-500/10 border border-cyan-500/30 rounded-xl flex items-center justify-center text-cyan-400 group-hover:scale-110 transition">
                  <FileCode className="w-6 h-6" />
                </div>
                <p className="text-sm font-bold text-zinc-200">
                  {fileName ? fileName : 'Click to select ISO / ROM file or drag & drop'}
                </p>
                <p className="text-xs text-zinc-500 font-mono">
                  Supports .iso, .cso, .bin, .gba, .z64 (PSP, PS2, PS1, GameCube, GBA)
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1">Game Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. God of War"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-zinc-100 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1">Gaming System</label>
                <select
                  value={system}
                  onChange={(e) => setSystem(e.target.value as GamingSystem)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-zinc-100 focus:outline-none focus:border-cyan-500"
                >
                  <option value="PSP">PSP (PlayStation Portable)</option>
                  <option value="PS2">PlayStation 2</option>
                  <option value="PS1">PlayStation 1</option>
                  <option value="GameCube">Nintendo GameCube</option>
                  <option value="N64">Nintendo 64</option>
                  <option value="GBA">Game Boy Advance</option>
                  <option value="Arcade">Arcade MAME</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1">Region</label>
                <select
                  value={region}
                  onChange={(e) => setRegion(e.target.value as any)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-zinc-100 focus:outline-none focus:border-cyan-500"
                >
                  <option value="USA">USA (English)</option>
                  <option value="EUR">Europe</option>
                  <option value="JPN">Japan</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1">Genre</label>
                <input
                  type="text"
                  placeholder="Action, RPG, Fighting..."
                  value={genre}
                  onChange={(e) => setGenre(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-zinc-100 focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1">Description</label>
              <textarea
                rows={2}
                placeholder="Enter game summary..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-zinc-100 focus:outline-none focus:border-cyan-500 resize-none"
              ></textarea>
            </div>

            <div className="pt-2 flex justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-bold rounded-xl transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-zinc-950 text-xs font-extrabold rounded-xl shadow-lg shadow-cyan-500/20 transition"
              >
                Import & Add to Library
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
