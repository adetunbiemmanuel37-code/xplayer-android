import React from 'react';
import { Play, Star, Sparkles, Clock, HardDrive } from 'lucide-react';
import { Game } from '../types';

interface GameCardProps {
  game: Game;
  onPlay: (game: Game) => void;
  onToggleFavorite: (gameId: string) => void;
  onOpenDetails: (game: Game) => void;
}

export const GameCard: React.FC<GameCardProps> = ({
  game,
  onPlay,
  onToggleFavorite,
  onOpenDetails
}) => {
  return (
    <div className="group relative bg-zinc-900/90 border border-zinc-800 hover:border-cyan-500/50 rounded-2xl overflow-hidden shadow-lg hover:shadow-cyan-500/15 transition-all duration-300 flex flex-col">
      
      {/* Cover Image & Overlay */}
      <div className="relative aspect-[16/10] overflow-hidden bg-zinc-950 cursor-pointer" onClick={() => onOpenDetails(game)}>
        <img
          src={game.coverUrl}
          alt={game.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent opacity-80 group-hover:opacity-60 transition-opacity"></div>
        
        {/* System Badge */}
        <div className="absolute top-3 left-3 flex items-center gap-1.5">
          <span className="px-2.5 py-1 bg-zinc-950/80 backdrop-blur-md border border-cyan-500/40 text-cyan-400 font-mono text-[10px] font-bold rounded-lg shadow">
            {game.system}
          </span>
          <span className="px-2 py-1 bg-purple-950/80 backdrop-blur-md border border-purple-500/40 text-purple-300 font-mono text-[10px] font-bold rounded-lg flex items-center gap-1 shadow">
            <Sparkles className="w-3 h-3 text-purple-400" /> 4K
          </span>
        </div>

        {/* Favorite Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite(game.id);
          }}
          className={`absolute top-3 right-3 w-8 h-8 rounded-xl backdrop-blur-md border flex items-center justify-center transition ${game.isFavorite ? 'bg-amber-500/20 border-amber-500/50 text-amber-400' : 'bg-zinc-950/60 border-zinc-800 text-zinc-400 hover:text-white'}`}
          title={game.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
        >
          <Star className={`w-4 h-4 ${game.isFavorite ? 'fill-amber-400' : ''}`} />
        </button>

        {/* Play Overlay Button on Hover */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-zinc-950/40 backdrop-blur-[2px]">
          <button
            onClick={() => onPlay(game)}
            className="px-5 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-zinc-950 font-extrabold rounded-xl shadow-xl shadow-cyan-500/30 flex items-center gap-2 transform group-hover:scale-105 transition"
          >
            <Play className="w-5 h-5 fill-zinc-950" />
            <span>Launch Game</span>
          </button>
        </div>
      </div>

      {/* Game Info */}
      <div className="p-4 flex flex-col flex-grow justify-between gap-3">
        <div>
          <div className="flex items-center justify-between text-xs text-zinc-400 mb-1 font-mono">
            <span>{game.genre}</span>
            <span className="text-amber-400 flex items-center gap-1">★ {game.rating}</span>
          </div>
          <h3 
            onClick={() => onOpenDetails(game)}
            className="font-bold text-zinc-100 text-base line-clamp-1 hover:text-cyan-400 cursor-pointer transition"
          >
            {game.title}
          </h3>
          <p className="text-xs text-zinc-400 line-clamp-2 mt-1">
            {game.description}
          </p>
        </div>

        <div className="pt-3 border-t border-zinc-800/80 flex items-center justify-between text-xs text-zinc-500 font-mono">
          <span className="flex items-center gap-1">
            <HardDrive className="w-3.5 h-3.5 text-cyan-400" /> {game.fileSize}
          </span>
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-purple-400" /> {game.playTimeMinutes} mins
          </span>
        </div>
      </div>

    </div>
  );
};
