import React, { useState, useEffect, useRef } from 'react';
import { Game, GraphicsSettings } from '../types';
import { 
  ArrowLeft, Play, Pause, FastForward, RotateCcw, Save, Download, 
  Sliders, Code, Maximize2, Volume2, VolumeX, Shield, Smartphone, Zap, Sparkles 
} from 'lucide-react';

interface EmulatorScreenProps {
  game: Game;
  graphics: GraphicsSettings;
  onClose: () => void;
  onOpenCheats: () => void;
  onOpenGraphics: () => void;
}

export const EmulatorScreen: React.FC<EmulatorScreenProps> = ({
  game,
  graphics,
  onClose,
  onOpenCheats,
  onOpenGraphics
}) => {
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1);
  const [showTouchControls, setShowTouchControls] = useState<boolean>(true);
  const [fps, setFps] = useState<number>(120);
  const [activeButtons, setActiveButtons] = useState<{ [key: string]: boolean }>({});
  const [saveSlots, setSaveSlots] = useState<{ [slot: number]: string }>({});
  const [notification, setNotification] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Trigger temporary notification
  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 2500);
  };

  // Interactive Retro Canvas Game Simulation loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let playerX = 200;
    let playerY = 150;
    const playerSize = 32;
    let enemies: { x: number; y: number; speed: number; color: string }[] = [
      { x: 100, y: 80, speed: 2, color: '#00f0ff' },
      { x: 500, y: 220, speed: 2.5, color: '#a855f7' },
      { x: 300, y: 350, speed: 1.8, color: '#ec4899' },
    ];
    let score = 0;

    const render = () => {
      if (!isPlaying) {
        animationFrameId = requestAnimationFrame(render);
        return;
      }

      // Background
      ctx.fillStyle = '#09090b';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Grid / Cyberpunk floor lines
      ctx.strokeStyle = '#18181b';
      ctx.lineWidth = 1;
      for (let i = 0; i < canvas.width; i += 40) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, canvas.height);
        ctx.stroke();
      }
      for (let j = 0; j < canvas.height; j += 40) {
        ctx.beginPath();
        ctx.moveTo(0, j);
        ctx.lineTo(canvas.width, j);
        ctx.stroke();
      }

      // Handle Virtual/Physical inputs
      const speed = 4 * speedMultiplier;
      if (activeButtons['up'] || activeButtons['KeyW']) playerY = Math.max(20, playerY - speed);
      if (activeButtons['down'] || activeButtons['KeyS']) playerY = Math.min(canvas.height - 40, playerY + speed);
      if (activeButtons['left'] || activeButtons['KeyA']) playerX = Math.max(20, playerX - speed);
      if (activeButtons['right'] || activeButtons['KeyD']) playerX = Math.min(canvas.width - 40, playerX + speed);

      // Render Player (Kratos / Hero representation with glowing 4K aura)
      ctx.shadowBlur = graphics.shaderEffect.includes('Bloom') ? 25 : 10;
      ctx.shadowColor = '#00f0ff';
      ctx.fillStyle = '#00f0ff';
      ctx.fillRect(playerX - playerSize / 2, playerY - playerSize / 2, playerSize, playerSize);
      
      // Inner core
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(playerX - playerSize / 4, playerY - playerSize / 4, playerSize / 2, playerSize / 2);
      ctx.shadowBlur = 0;

      // Render Enemies & Update
      enemies.forEach((enemy) => {
        enemy.x += enemy.speed * (playerX > enemy.x ? 1 : -1) * 0.7;
        enemy.y += enemy.speed * (playerY > enemy.y ? 1 : -1) * 0.7;

        ctx.fillStyle = enemy.color;
        ctx.beginPath();
        ctx.arc(enemy.x, enemy.y, 16, 0, Math.PI * 2);
        ctx.fill();

        // Check collision for score
        const dist = Math.hypot(playerX - enemy.x, playerY - enemy.y);
        if (dist < 24) {
          score += 10;
          enemy.x = Math.random() * (canvas.width - 50) + 25;
          enemy.y = Math.random() * (canvas.height - 50) + 25;
        }
      });

      // Render HUD inside Canvas
      ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      ctx.fillRect(15, 15, 220, 50);
      ctx.strokeStyle = 'rgba(0, 240, 255, 0.3)';
      ctx.strokeRect(15, 15, 220, 50);

      ctx.fillStyle = '#00f0ff';
      ctx.font = 'bold 12px monospace';
      ctx.fillText(`XPLAYER 4K • ${game.system}`, 25, 33);
      ctx.fillStyle = '#a855f7';
      ctx.fillText(`SCORE: ${score} | FPS: ${fps}`, 25, 53);

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isPlaying, speedMultiplier, activeButtons, graphics, game.system, fps]);

  // Handle Keyboard listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      setActiveButtons(prev => ({ ...prev, [e.code]: true }));
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      setActiveButtons(prev => ({ ...prev, [e.code]: false }));
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const handleTouchButtonStart = (btn: string) => {
    setActiveButtons(prev => ({ ...prev, [btn]: true }));
  };
  const handleTouchButtonEnd = (btn: string) => {
    setActiveButtons(prev => ({ ...prev, [btn]: false }));
  };

  const handleSaveState = (slot: number) => {
    setSaveSlots(prev => ({ ...prev, [slot]: new Date().toLocaleTimeString() }));
    showNotification(`Game State saved to Slot ${slot}!`);
  };

  const handleLoadState = (slot: number) => {
    if (saveSlots[slot]) {
      showNotification(`Loaded Slot ${slot} (${saveSlots[slot]})`);
    } else {
      showNotification(`Slot ${slot} is empty.`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-zinc-950 flex flex-col select-none overflow-hidden">
      
      {/* Top Bar */}
      <div className="bg-zinc-950/90 border-b border-cyan-500/30 px-4 py-3 flex items-center justify-between z-20">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-cyan-400 rounded-xl border border-zinc-800 transition flex items-center gap-1.5 text-xs font-bold"
          >
            <ArrowLeft className="w-4 h-4" /> Exit Emulator
          </button>
          <div>
            <h1 className="text-sm font-black text-zinc-100 flex items-center gap-2">
              <span>{game.title}</span>
              <span className="px-2 py-0.5 bg-cyan-500/20 text-cyan-400 font-mono text-[10px] rounded border border-cyan-500/30">
                {graphics.resolutionScale}
              </span>
            </h1>
            <p className="text-[11px] text-zinc-400 font-mono">
              XPlayer Engine • Maker: Adetunbi Emmanuel • 120Hz 4K Upscaled
            </p>
          </div>
        </div>

        {/* Quick Tools */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 rounded-xl border border-zinc-800 transition"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? <Pause className="w-4 h-4 text-amber-400" /> : <Play className="w-4 h-4 text-emerald-400" />}
          </button>

          <button
            onClick={() => setSpeedMultiplier(prev => (prev === 1 ? 2 : prev === 2 ? 4 : 1))}
            className="px-2.5 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-cyan-400 rounded-xl border border-zinc-800 text-xs font-mono font-bold transition flex items-center gap-1"
            title="Fast Forward Speed"
          >
            <FastForward className="w-3.5 h-3.5" /> {speedMultiplier}x
          </button>

          <button
            onClick={onOpenCheats}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 rounded-xl text-xs font-bold transition"
          >
            <Code className="w-3.5 h-3.5" /> Cheats
          </button>

          <button
            onClick={onOpenGraphics}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 rounded-xl text-xs font-bold transition"
          >
            <Sliders className="w-3.5 h-3.5" /> 4K FX
          </button>

          <button
            onClick={() => setShowTouchControls(!showTouchControls)}
            className={`p-2 rounded-xl border transition ${showTouchControls ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-400' : 'bg-zinc-900 border-zinc-800 text-zinc-400'}`}
            title="Toggle Touch Gamepad"
          >
            <Smartphone className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Notification toast */}
      {notification && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-50 bg-cyan-500 text-zinc-950 font-bold px-4 py-2 rounded-xl shadow-2xl text-xs flex items-center gap-2 animate-bounce">
          <Sparkles className="w-4 h-4" /> {notification}
        </div>
      )}

      {/* Center Emulator Viewport */}
      <div className="relative flex-grow flex items-center justify-center bg-black overflow-hidden">
        
        {/* CRT Scanline Shader Overlay if selected */}
        {graphics.shaderEffect.includes('CRT') && (
          <div className="absolute inset-0 pointer-events-none z-10 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%)] bg-[length:100%_4px]"></div>
        )}

        {/* HDR Bloom glow overlay */}
        {graphics.shaderEffect.includes('Bloom') && (
          <div className="absolute inset-0 pointer-events-none z-10 shadow-[inset_0_0_100px_rgba(0,240,255,0.15)]"></div>
        )}

        {/* Canvas Display */}
        <canvas
          ref={canvasRef}
          width={800}
          height={450}
          className="w-full max-w-5xl aspect-video object-contain shadow-2xl border border-zinc-800/80 rounded-lg bg-zinc-950"
        />

        {/* Performance HUD Top-Right */}
        <div className="absolute top-4 right-4 z-20 bg-zinc-950/80 backdrop-blur-md border border-zinc-800 px-3 py-2 rounded-xl font-mono text-[11px] text-cyan-400 space-y-0.5 shadow-lg hidden md:block">
          <div>FPS: {fps} (120Hz Target)</div>
          <div>RES: 3840 x 2160 (4K UHD)</div>
          <div className="text-purple-400">GPU: XPlayer Ultra Engine</div>
        </div>

        {/* Save/Load Quick Bar Bottom-Right */}
        <div className="absolute bottom-4 right-4 z-20 bg-zinc-950/80 backdrop-blur-md border border-zinc-800 p-2 rounded-xl flex items-center gap-2 shadow-lg">
          <span className="text-[10px] font-bold uppercase text-zinc-400 px-1">States:</span>
          {[1, 2, 3].map(slot => (
            <div key={slot} className="flex items-center gap-1">
              <button
                onClick={() => handleSaveState(slot)}
                className="px-2 py-1 bg-zinc-900 hover:bg-cyan-500 hover:text-zinc-950 text-zinc-300 rounded text-[11px] font-mono transition"
                title={`Save Slot ${slot}`}
              >
                S{slot}
              </button>
              <button
                onClick={() => handleLoadState(slot)}
                className="px-2 py-1 bg-zinc-900 hover:bg-purple-500 hover:text-zinc-950 text-zinc-300 rounded text-[11px] font-mono transition"
                title={`Load Slot ${slot}`}
              >
                L{slot}
              </button>
            </div>
          ))}
        </div>

      </div>

      {/* Touch Gamepad Overlay (Optimized for Android, Windows Touch, & Tablets) */}
      {showTouchControls && (
        <div className="bg-zinc-950/90 border-t border-zinc-800/80 p-4 grid grid-cols-3 items-center justify-between z-30 select-none">
          
          {/* D-Pad (Left) */}
          <div className="flex items-center justify-center">
            <div className="relative w-32 h-32 bg-zinc-900/80 border border-zinc-800 rounded-full flex items-center justify-center shadow-inner">
              <button
                onMouseDown={() => handleTouchButtonStart('up')}
                onMouseUp={() => handleTouchButtonEnd('up')}
                onTouchStart={() => handleTouchButtonStart('up')}
                onTouchEnd={() => handleTouchButtonEnd('up')}
                className="absolute top-2 w-10 h-10 bg-zinc-800 hover:bg-cyan-500 hover:text-zinc-950 text-zinc-300 rounded-t-lg font-bold flex items-center justify-center transition active:bg-cyan-400 shadow"
              >
                ▲
              </button>
              <button
                onMouseDown={() => handleTouchButtonStart('down')}
                onMouseUp={() => handleTouchButtonEnd('down')}
                onTouchStart={() => handleTouchButtonStart('down')}
                onTouchEnd={() => handleTouchButtonEnd('down')}
                className="absolute bottom-2 w-10 h-10 bg-zinc-800 hover:bg-cyan-500 hover:text-zinc-950 text-zinc-300 rounded-b-lg font-bold flex items-center justify-center transition active:bg-cyan-400 shadow"
              >
                ▼
              </button>
              <button
                onMouseDown={() => handleTouchButtonStart('left')}
                onMouseUp={() => handleTouchButtonEnd('left')}
                onTouchStart={() => handleTouchButtonStart('left')}
                onTouchEnd={() => handleTouchButtonEnd('left')}
                className="absolute left-2 w-10 h-10 bg-zinc-800 hover:bg-cyan-500 hover:text-zinc-950 text-zinc-300 rounded-l-lg font-bold flex items-center justify-center transition active:bg-cyan-400 shadow"
              >
                ◀
              </button>
              <button
                onMouseDown={() => handleTouchButtonStart('right')}
                onMouseUp={() => handleTouchButtonEnd('right')}
                onTouchStart={() => handleTouchButtonStart('right')}
                onTouchEnd={() => handleTouchButtonEnd('right')}
                className="absolute right-2 w-10 h-10 bg-zinc-800 hover:bg-cyan-500 hover:text-zinc-950 text-zinc-300 rounded-r-lg font-bold flex items-center justify-center transition active:bg-cyan-400 shadow"
              >
                ▶
              </button>
              <div className="w-8 h-8 bg-zinc-950 rounded-full border border-zinc-800"></div>
            </div>
          </div>

          {/* Center Select / Start / L / R */}
          <div className="flex flex-col items-center gap-3">
            <div className="flex items-center gap-4">
              <button
                onMouseDown={() => handleTouchButtonStart('KeyQ')}
                onMouseUp={() => handleTouchButtonEnd('KeyQ')}
                className="px-4 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 rounded-lg text-xs font-mono text-zinc-300 shadow"
              >
                L1
              </button>
              <button
                onMouseDown={() => handleTouchButtonStart('KeyE')}
                onMouseUp={() => handleTouchButtonEnd('KeyE')}
                className="px-4 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 rounded-lg text-xs font-mono text-zinc-300 shadow"
              >
                R1
              </button>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => showNotification('Select Pressed')}
                className="px-3 py-1 bg-zinc-900 text-zinc-400 rounded-md text-[10px] font-mono border border-zinc-800"
              >
                SELECT
              </button>
              <button
                onClick={() => showNotification('Start Pressed')}
                className="px-3 py-1 bg-zinc-900 text-zinc-400 rounded-md text-[10px] font-mono border border-zinc-800"
              >
                START
              </button>
            </div>
          </div>

          {/* Action Buttons (Right) */}
          <div className="flex items-center justify-center">
            <div className="relative w-36 h-36 bg-zinc-900/80 border border-zinc-800 rounded-full flex items-center justify-center shadow-inner">
              <button
                onMouseDown={() => handleTouchButtonStart('KeyW')}
                onMouseUp={() => handleTouchButtonEnd('KeyW')}
                className="absolute top-2 w-10 h-10 bg-purple-950/80 border border-purple-500/50 hover:bg-purple-600 text-purple-200 rounded-full font-bold flex items-center justify-center shadow-lg text-sm"
              >
                ▲
              </button>
              <button
                onMouseDown={() => handleTouchButtonStart('KeyS')}
                onMouseUp={() => handleTouchButtonEnd('KeyS')}
                className="absolute bottom-2 w-10 h-10 bg-cyan-950/80 border border-cyan-500/50 hover:bg-cyan-600 text-cyan-200 rounded-full font-bold flex items-center justify-center shadow-lg text-sm"
              >
                ✖
              </button>
              <button
                onMouseDown={() => handleTouchButtonStart('KeyA')}
                onMouseUp={() => handleTouchButtonEnd('KeyA')}
                className="absolute left-2 w-10 h-10 bg-amber-950/80 border border-amber-500/50 hover:bg-amber-600 text-amber-200 rounded-full font-bold flex items-center justify-center shadow-lg text-sm"
              >
                ■
              </button>
              <button
                onMouseDown={() => handleTouchButtonStart('KeyD')}
                onMouseUp={() => handleTouchButtonEnd('KeyD')}
                className="absolute right-2 w-10 h-10 bg-emerald-950/80 border border-emerald-500/50 hover:bg-emerald-600 text-emerald-200 rounded-full font-bold flex items-center justify-center shadow-lg text-sm"
              >
                ●
              </button>
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
