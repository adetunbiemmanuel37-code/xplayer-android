import React, { useState } from 'react';
import { X, Code, Plus, Check, Trash2 } from 'lucide-react';
import { CheatCode } from '../types';

interface CheatsModalProps {
  cheats: CheatCode[];
  onToggleCheat: (id: string) => void;
  onAddCheat: (cheat: CheatCode) => void;
  onClose: () => void;
}

export const CheatsModal: React.FC<CheatsModalProps> = ({
  cheats,
  onToggleCheat,
  onAddCheat,
  onClose
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [title, setTitle] = useState('');
  const [code, setCode] = useState('');
  const [description, setDescription] = useState('');

  const handleAddNewCheat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !code) return;

    const newCheat: CheatCode = {
      id: `cheat-${Date.now()}`,
      gameId: 'god-of-war-chains',
      title: title.trim(),
      code: code.trim(),
      enabled: true,
      description: description.trim() || 'Custom user added cheat code'
    };

    onAddCheat(newCheat);
    setTitle('');
    setCode('');
    setDescription('');
    setShowAddForm(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-zinc-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-zinc-900 border border-purple-500/30 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="px-6 py-4 bg-zinc-950 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Code className="w-5 h-5 text-purple-400" />
            <h2 className="text-base font-bold text-zinc-100">Cheat Code Database & CWCheat</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 overflow-y-auto flex-grow">
          
          <div className="flex items-center justify-between">
            <p className="text-xs text-zinc-400">Toggle or add Action Replay / CWCheat codes for active games.</p>
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="px-3 py-1.5 bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 rounded-xl text-xs font-bold flex items-center gap-1 transition"
            >
              <Plus className="w-3.5 h-3.5" /> Add Cheat
            </button>
          </div>

          {showAddForm && (
            <form onSubmit={handleAddNewCheat} className="bg-zinc-950 border border-zinc-800 p-4 rounded-2xl space-y-3">
              <h3 className="text-xs font-bold text-cyan-400 uppercase">New Cheat Code</h3>
              <input
                type="text"
                required
                placeholder="Cheat Title (e.g. Infinite Ammo)"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-100 focus:outline-none focus:border-cyan-500"
              />
              <input
                type="text"
                required
                placeholder="Hex Code (e.g. 0x004F2190 0x00000001)"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs font-mono text-zinc-100 focus:outline-none focus:border-cyan-500"
              />
              <input
                type="text"
                placeholder="Description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-100 focus:outline-none focus:border-cyan-500"
              />
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-3 py-1 bg-zinc-800 text-zinc-300 text-xs rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1 bg-purple-600 text-white font-bold text-xs rounded-lg"
                >
                  Save Cheat
                </button>
              </div>
            </form>
          )}

          {/* List of Cheats */}
          <div className="space-y-2">
            {cheats.map((cheat) => (
              <div
                key={cheat.id}
                onClick={() => onToggleCheat(cheat.id)}
                className={`p-4 rounded-2xl border cursor-pointer transition flex items-center justify-between ${cheat.enabled ? 'bg-purple-500/10 border-purple-500/40 text-zinc-100 shadow' : 'bg-zinc-950/60 border-zinc-800 text-zinc-400 hover:border-zinc-700'}`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold">{cheat.title}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${cheat.enabled ? 'bg-purple-500 text-zinc-950' : 'bg-zinc-900 text-zinc-500'}`}>
                      {cheat.enabled ? 'ACTIVE' : 'OFF'}
                    </span>
                  </div>
                  <p className="text-xs text-zinc-400">{cheat.description}</p>
                  <p className="text-[11px] font-mono text-cyan-400 bg-zinc-950 px-2 py-0.5 rounded inline-block border border-zinc-800">
                    {cheat.code}
                  </p>
                </div>

                <div className={`w-6 h-6 rounded-lg border flex items-center justify-center transition ${cheat.enabled ? 'bg-purple-500 border-purple-400 text-zinc-950 font-bold' : 'bg-zinc-900 border-zinc-800 text-transparent'}`}>
                  ✓
                </div>
              </div>
            ))}
          </div>

        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-zinc-950 border-t border-zinc-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white font-bold rounded-xl text-xs transition"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
