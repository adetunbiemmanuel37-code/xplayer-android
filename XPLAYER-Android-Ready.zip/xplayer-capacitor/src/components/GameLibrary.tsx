import React from 'react';
import { Game, GamingSystem } from '../types';
import { GameCard } from './GameCard';
import { Play, Sparkles, PlusCircle, Gamepad2, Layers } from 'lucide-react';

interface GameLibraryProps {
  games: Game[];
  selectedSystem: GamingSystem | 'ALL' | 'FAVORITES';
  searchQuery: string;
  onPlay: (game: Game) => void;
  onToggleFavorite: (gameId: string) => void;
  onOpenDetails: (game: Game) => void;
  onOpenImporter: () => void;
}

export const GameLibrary: React.FC<GameLibraryProps> = ({
  games,
  selectedSystem,
  searchQuery,
  onPlay,
  onToggleFavorite,
  onOpenDetails,
  onOpenImporter
}) => {
  // Filter games based on system and search query
  const filteredGames = games.filter((game) => {
    const matchesSystem = 
      selectedSystem === 'ALL' ? true :
      selectedSystem === 'FAVORITES' ? game.isFavorite :
      game.system === selectedSystem;

    const matchesSearch = 
      game.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      game.genre.toLowerCase().includes(searchQuery.toLowerCase()) ||
      game.system.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesSystem && matchesSearch;
  });

  const featuredGame = games[0]; // God of War Chains of Olympus or first game

  return (
    <div className="space-y-8 pb-12">
      
      {/* Featured Hero Banner (Only shown if no active search or ALL selected) && featuredGame exists */}
      {selectedSystem === 'ALL' && !searchQuery && featuredGame && (
        <div className="relative rounded-3xl overflow-hidden border border-cyan-500/30 bg-zinc-950 shadow-2xl">
          <div className="absolute inset-0">
            <img
              src={featuredGame.bannerUrl}
              alt={featuredGame.title}
              className="w-full h-full object-cover opacity-40 blur-[1px] transform hover:scale-105 transition duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/80 to-transparent"></div>
          </div>

          <div className="relative z-10 p-6 md:p-10 max-w-2xl flex flex-col items-start gap-4">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 bg-cyan-500/20 border border-cyan-500/50 text-cyan-300 text-xs font-bold rounded-full flex items-center gap-1.5 shadow">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> Featured 4K ISO Remaster
              </span>
              <span className="px-3 py-1 bg-purple-500/20 border border-purple-500/50 text-purple-300 text-xs font-bold rounded-full font-mono">
                {featuredGame.system}
              </span>
            </div>

            <h1 className="text-3xl md:text-5xl font-extrabold text-zinc-100 tracking-tight leading-tight">
              {featuredGame.title}
            </h1>

            <p className="text-sm md:text-base text-zinc-300 line-clamp-2">
              {featuredGame.description}
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => onPlay(featuredGame)}
                className="px-6 py-3 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-zinc-950 font-extrabold rounded-xl shadow-lg shadow-cyan-500/25 flex items-center gap-2 transition transform active:scale-95"
              >
                <Play className="w-5 h-5 fill-zinc-950" />
                <span>Play in 4K Now</span>
              </button>

              <button
                onClick={() => onOpenDetails(featuredGame)}
                className="px-5 py-3 bg-zinc-900/90 hover:bg-zinc-800 border border-zinc-700 text-zinc-200 font-semibold rounded-xl flex items-center gap-2 transition"
              >
                <Layers className="w-4 h-4 text-purple-400" />
                <span>Game Details & Cheats</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header Bar for Section */}
      <div className="flex items-center justify-between border-b border-zinc-800/80 pb-4">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-zinc-100 flex items-center gap-2">
            <span>{selectedSystem === 'ALL' ? 'All ISO Games' : selectedSystem === 'FAVORITES' ? 'Favorite Games' : `${selectedSystem} ISO Library`}</span>
            <span className="text-xs font-mono font-normal px-2.5 py-0.5 bg-zinc-900 text-cyan-400 border border-cyan-500/20 rounded-full">
              {filteredGames.length} titles
            </span>
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Crafted by Adetunbi Emmanuel • High performance 4K retro emulation
          </p>
        </div>

        <button
          onClick={onOpenImporter}
          className="hidden sm:flex items-center gap-2 px-4 py-2 bg-zinc-900 hover:bg-zinc-800 border border-cyan-500/30 text-cyan-400 hover:text-cyan-300 rounded-xl text-xs font-bold transition shadow-sm"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Add New ISO</span>
        </button>
      </div>

      {/* Grid of Games */}
      {filteredGames.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredGames.map((game) => (
            <GameCard
              key={game.id}
              game={game}
              onPlay={onPlay}
              onToggleFavorite={onToggleFavorite}
              onOpenDetails={onOpenDetails}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-zinc-900/40 border border-zinc-800 rounded-3xl p-8 space-y-4">
          <div className="w-16 h-16 bg-zinc-900 border border-zinc-800 rounded-2xl mx-auto flex items-center justify-center text-cyan-400">
            <Gamepad2 className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-zinc-200">No ISO games found</h3>
          <p className="text-sm text-zinc-400 max-w-md mx-auto">
            {searchQuery ? `No results matching "${searchQuery}". Try a different search term or system filter.` : 'Your library for this system is currently empty. Import your `.iso` or `.cso` ROM files to start playing.'}
          </p>
          <button
            onClick={onOpenImporter}
            className="px-6 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-zinc-950 font-bold rounded-xl text-xs transition shadow-lg shadow-cyan-500/20"
          >
            Import ISO Game File
          </button>
        </div>
      )}

    </div>
  );
};
