import React from 'react';
import { Gamepad2, Sparkles, Sliders, Smartphone, Monitor, ShieldCheck, Search } from 'lucide-react';

interface NavbarProps {
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onOpenSettings: () => void;
  onOpenController: () => void;
  onOpenAbout: () => void;
  activeDevice: 'android' | 'windows' | 'tablet';
  setActiveDevice: (device: 'android' | 'windows' | 'tablet') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  searchQuery,
  setSearchQuery,
  onOpenSettings,
  onOpenController,
  onOpenAbout,
  activeDevice,
  setActiveDevice
}) => {
  return (
    <header className="sticky top-0 z-40 bg-zinc-950/80 backdrop-blur-xl border-b border-cyan-500/20 px-4 lg:px-8 py-3">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Brand & Maker */}
        <div className="flex items-center gap-3">
          <div className="relative group cursor-pointer" onClick={onOpenAbout}>
            <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-300"></div>
            <div className="relative w-11 h-11 bg-zinc-900 rounded-xl border border-cyan-400/50 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Gamepad2 className="w-6 h-6 text-cyan-400 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-black tracking-wider bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
                XPLAYER
              </span>
              <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 rounded-full flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> 4K ULTRA
              </span>
            </div>
            <p className="text-xs text-zinc-400 font-medium flex items-center gap-1.5">
              <span>By <strong className="text-cyan-300">Adetunbi Emmanuel</strong></span>
              <span className="text-zinc-600">•</span>
              <span className="text-emerald-400 font-mono text-[11px]">Superior to PPSSPP Gold</span>
            </p>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
          <input
            type="text"
            placeholder="Search ISO games, system, genre..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-900/90 border border-zinc-800 focus:border-cyan-500/60 rounded-xl pl-10 pr-4 py-2 text-sm text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 transition-all shadow-inner"
          />
        </div>

        {/* Controls & Device Toggles */}
        <div className="flex items-center gap-2.5">
          {/* Device Preset Switcher */}
          <div className="hidden xl:flex items-center bg-zinc-900/80 border border-zinc-800 rounded-xl p-1">
            <button
              onClick={() => setActiveDevice('android')}
              title="Android Mobile Mode"
              className={`px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1 transition ${activeDevice === 'android' ? 'bg-cyan-500 text-zinc-950 font-bold shadow' : 'text-zinc-400 hover:text-zinc-200'}`}
            >
              <Smartphone className="w-3.5 h-3.5" /> Android
            </button>
            <button
              onClick={() => setActiveDevice('windows')}
              title="Windows PC Mode"
              className={`px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1 transition ${activeDevice === 'windows' ? 'bg-cyan-500 text-zinc-950 font-bold shadow' : 'text-zinc-400 hover:text-zinc-200'}`}
            >
              <Monitor className="w-3.5 h-3.5" /> Windows
            </button>
            <button
              onClick={() => setActiveDevice('tablet')}
              title="Tablet Mode"
              className={`px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1 transition ${activeDevice === 'tablet' ? 'bg-cyan-500 text-zinc-950 font-bold shadow' : 'text-zinc-400 hover:text-zinc-200'}`}
            >
              <ShieldCheck className="w-3.5 h-3.5" /> Tablet
            </button>
          </div>

          <button
            onClick={onOpenController}
            className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-cyan-500/40 text-zinc-200 px-3 py-2 rounded-xl text-xs font-medium flex items-center gap-2 transition shadow-sm"
          >
            <Gamepad2 className="w-4 h-4 text-cyan-400" />
            <span className="hidden sm:inline">Controller</span>
          </button>

          <button
            onClick={onOpenSettings}
            className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-cyan-500/40 text-zinc-200 px-3 py-2 rounded-xl text-xs font-medium flex items-center gap-2 transition shadow-sm"
          >
            <Sliders className="w-4 h-4 text-purple-400" />
            <span className="hidden sm:inline">4K Graphics</span>
          </button>

          <button
            onClick={onOpenAbout}
            className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-zinc-950 px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-cyan-500/25 transition transform active:scale-95"
          >
            <Sparkles className="w-4 h-4" />
            <span>About</span>
          </button>
        </div>

      </div>
    </header>
  );
};
