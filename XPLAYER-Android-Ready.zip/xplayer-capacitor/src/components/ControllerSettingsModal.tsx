import React, { useState, useEffect } from 'react';
import { X, Gamepad2, CheckCircle, Smartphone } from 'lucide-react';

interface ControllerSettingsModalProps {
  onClose: () => void;
}

export const ControllerSettingsModal: React.FC<ControllerSettingsModalProps> = ({ onClose }) => {
  const [gamepadConnected, setGamepadConnected] = useState<boolean>(false);
  const [gamepadName, setGamepadName] = useState<string>('No physical gamepad detected');

  useEffect(() => {
    const handleGamepadConnected = (e: GamepadEvent) => {
      setGamepadConnected(true);
      setGamepadName(e.gamepad.id);
    };

    const handleGamepadDisconnected = () => {
      setGamepadConnected(false);
      setGamepadName('No physical gamepad detected');
    };

    window.addEventListener('gamepadconnected', handleGamepadConnected as EventListener);
    window.addEventListener('gamepaddisconnected', handleGamepadDisconnected as EventListener);

    // Check existing
    const gamepads = navigator.getGamepads ? navigator.getGamepads() : [];
    for (let i = 0; i < gamepads.length; i++) {
      if (gamepads[i]) {
        setGamepadConnected(true);
        setGamepadName(gamepads[i]?.id || 'Standard USB/Bluetooth Controller');
        break;
      }
    }

    return () => {
      window.removeEventListener('gamepadconnected', handleGamepadConnected as EventListener);
      window.removeEventListener('gamepaddisconnected', handleGamepadDisconnected as EventListener);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-zinc-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-zinc-900 border border-cyan-500/30 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl">
        
        {/* Header */}
        <div className="px-6 py-4 bg-zinc-950 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Gamepad2 className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base font-bold text-zinc-100">Controller & Touch Mapping</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          
          {/* Gamepad Connection status */}
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 flex items-center gap-4">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${gamepadConnected ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-zinc-900 text-zinc-500 border border-zinc-800'}`}>
              <Gamepad2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-zinc-200">
                {gamepadConnected ? 'Physical Controller Connected' : 'Waiting for Gamepad...'}
              </h3>
              <p className="text-xs text-zinc-400 font-mono mt-0.5 truncate max-w-xs sm:max-w-sm">
                {gamepadName}
              </p>
            </div>
          </div>

          {/* Touch Overlay info */}
          <div className="bg-zinc-950/60 border border-zinc-800 rounded-2xl p-4 space-y-2">
            <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
              <Smartphone className="w-4 h-4" /> Android, Windows & Tablet Touch Support
            </h4>
            <p className="text-xs text-zinc-400 leading-relaxed">
              XPlayer features auto-scaling virtual touch pads on touchscreens (Android & Windows tablets) with custom haptic feedback simulation and adjustable button transparency.
            </p>
          </div>

          {/* Key Bindings List */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-zinc-400 uppercase tracking-wider">Default Keyboard & Gamepad Mapping</h4>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800 flex justify-between">
                <span className="text-zinc-400">D-Pad / Move</span>
                <span className="text-cyan-400 font-bold">W A S D / Arrow Keys</span>
              </div>
              <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800 flex justify-between">
                <span className="text-zinc-400">Cross (A)</span>
                <span className="text-cyan-400 font-bold">Key S / Space</span>
              </div>
              <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800 flex justify-between">
                <span className="text-zinc-400">Square (X)</span>
                <span className="text-cyan-400 font-bold">Key A</span>
              </div>
              <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800 flex justify-between">
                <span className="text-zinc-400">Triangle (Y)</span>
                <span className="text-cyan-400 font-bold">Key W</span>
              </div>
              <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800 flex justify-between">
                <span className="text-zinc-400">Circle (B)</span>
                <span className="text-cyan-400 font-bold">Key D</span>
              </div>
              <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800 flex justify-between">
                <span className="text-zinc-400">L1 / R1 Triggers</span>
                <span className="text-cyan-400 font-bold">Q / E</span>
              </div>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-zinc-950 border-t border-zinc-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-zinc-950 font-bold rounded-xl text-xs transition"
          >
            Save Mapping
          </button>
        </div>

      </div>
    </div>
  );
};
