import React from 'react';
import { Library, PlusCircle, Sliders, Gamepad2, Code, Info, Heart, HardDrive } from 'lucide-react';
import { GamingSystem } from '../types';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedSystem: GamingSystem | 'ALL' | 'FAVORITES';
  setSelectedSystem: (sys: GamingSystem | 'ALL' | 'FAVORITES') => void;
  gameCount: number;
  favoriteCount: number;
  onOpenImporter: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  selectedSystem,
  setSelectedSystem,
  gameCount,
  favoriteCount,
  onOpenImporter
}) => {
  const systems: { id: GamingSystem | 'ALL' | 'FAVORITES'; label: string; icon: string; count?: number }[] = [
    { id: 'ALL', label: 'All ISO Games', icon: '🎮', count: gameCount },
    { id: 'FAVORITES', label: 'Favorites', icon: '⭐', count: favoriteCount },
    { id: 'PSP', label: 'PlayStation Portable', icon: '🕹️' },
    { id: 'PS2', label: 'PlayStation 2', icon: '📀' },
    { id: 'PS1', label: 'PlayStation 1', icon: '💿' },
    { id: 'GameCube', label: 'Nintendo GameCube', icon: '🧊' },
    { id: 'N64', label: 'Nintendo 64', icon: '🎯' },
    { id: 'GBA', label: 'Game Boy Advance', icon: '👾' },
    { id: 'Arcade', label: 'Arcade / MAME', icon: '🎰' },
  ];

  return (
    <aside className="w-full lg:w-64 bg-zinc-950/60 lg:min-h-[calc(100vh-73px)] border-r border-zinc-800/80 p-4 flex flex-col gap-6">
      
      {/* Quick Action: Add ISO */}
      <button
        onClick={onOpenImporter}
        className="w-full bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 hover:opacity-95 text-zinc-950 font-bold p-3 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 transition transform active:scale-95"
      >
        <PlusCircle className="w-5 h-5 text-zinc-950" />
        <span className="text-sm tracking-wide">Import ISO / ROM</span>
      </button>

      {/* Navigation Links */}
      <div className="space-y-1">
        <p className="px-3 text-[11px] font-bold uppercase tracking-wider text-zinc-500 mb-2">Main Menu</p>
        
        <button
          onClick={() => setActiveTab('library')}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition ${activeTab === 'library' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30' : 'text-zinc-400 hover:bg-zinc-900 hover:text-zinc-200'}`}
        >
          <Library className="w-4 h-4" />
          <span>Game Library</span>
        </button>

        <button
          onClick={() => setActiveTab('graphics')}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition ${activeTab === 'graphics' ? 'bg-purple-500/10 text-purple-400 border border-purple-500/30' : 'text-zinc-400 hover:bg-zinc-900 hover:text-zinc-200'}`}
        >
          <Sliders className="w-4 h-4" />
          <span>4K Graphics Engine</span>
        </button>

        <button
          onClick={() => setActiveTab('controller')}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition ${activeTab === 'controller' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30' : 'text-zinc-400 hover:bg-zinc-900 hover:text-zinc-200'}`}
        >
          <Gamepad2 className="w-4 h-4" />
          <span>Gamepad & Touch</span>
        </button>

        <button
          onClick={() => setActiveTab('cheats')}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition ${activeTab === 'cheats' ? 'bg-purple-500/10 text-purple-400 border border-purple-500/30' : 'text-zinc-400 hover:bg-zinc-900 hover:text-zinc-200'}`}
        >
          <Code className="w-4 h-4" />
          <span>Cheat Codes DB</span>
        </button>
      </div>

      {/* Systems Filter List */}
      <div className="space-y-1">
        <p className="px-3 text-[11px] font-bold uppercase tracking-wider text-zinc-500 mb-2">Systems & Consoles</p>
        
        {systems.map((sys) => {
          const isSelected = activeTab === 'library' && selectedSystem === sys.id;
          return (
            <button
              key={sys.id}
              onClick={() => {
                setActiveTab('library');
                setSelectedSystem(sys.id);
              }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition ${isSelected ? 'bg-cyan-500/15 text-cyan-300 font-semibold border border-cyan-500/30' : 'text-zinc-400 hover:bg-zinc-900/60 hover:text-zinc-200'}`}
            >
              <div className="flex items-center gap-2.5">
                <span className="text-base">{sys.icon}</span>
                <span>{sys.label}</span>
              </div>
              {sys.count !== undefined && (
                <span className="px-2 py-0.5 bg-zinc-900 text-zinc-400 rounded-md font-mono text-[10px]">
                  {sys.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Storage & Creator Badge */}
      <div className="mt-auto pt-4 border-t border-zinc-800/85">
        <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-3 space-y-2">
          <div className="flex items-center justify-between text-xs text-zinc-400">
            <span className="flex items-center gap-1.5"><HardDrive className="w-3.5 h-3.5 text-cyan-400" /> Storage Cache</span>
            <span className="text-cyan-400 font-mono">18.4 GB / 256 GB</span>
          </div>
          <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
            <div className="bg-gradient-to-r from-cyan-500 to-purple-500 w-[42%] h-full rounded-full"></div>
          </div>
          <p className="text-[10px] text-zinc-500 pt-1 text-center font-mono">
            XPlayer v3.8 Pro • Adetunbi Emmanuel
          </p>
        </div>
      </div>

    </aside>
  );
};
