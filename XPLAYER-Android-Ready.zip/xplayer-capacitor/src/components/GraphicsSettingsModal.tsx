import React from 'react';
import { X, Sliders, Sparkles, Monitor, Cpu } from 'lucide-react';
import { GraphicsSettings } from '../types';

interface GraphicsSettingsModalProps {
  graphics: GraphicsSettings;
  setGraphics: React.Dispatch<React.SetStateAction<GraphicsSettings>>;
  onClose: () => void;
}

export const GraphicsSettingsModal: React.FC<GraphicsSettingsModalProps> = ({
  graphics,
  setGraphics,
  onClose
}) => {
  const handleChange = (key: keyof GraphicsSettings, value: any) => {
    setGraphics(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="fixed inset-0 z-50 bg-zinc-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-zinc-900 border border-purple-500/30 rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="px-6 py-4 bg-zinc-950 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-purple-400" />
            <div>
              <h2 className="text-base font-bold text-zinc-100">XPlayer 4K Graphics Engine</h2>
              <p className="text-[11px] text-zinc-400 font-mono">Outperforms PPSSPP Gold rendering engine</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 overflow-y-auto">
          
          {/* Resolution Scale */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" /> Resolution Scaling (4K Upscaling)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(['1x (Native)', '2x (1080p)', '4x (4K Ultra HD)', '8x (Extreme 4K+)'] as const).map((scale) => (
                <button
                  key={scale}
                  onClick={() => handleChange('resolutionScale', scale)}
                  className={`p-3 rounded-xl border text-xs font-bold text-center transition ${graphics.resolutionScale === scale ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'}`}
                >
                  {scale}
                </button>
              ))}
            </div>
          </div>

          {/* Shaders & Post-Processing */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-purple-400 flex items-center gap-1.5">
              <Monitor className="w-4 h-4" /> Shader Effects & Post-Processing
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {(['None', 'CRT Scanlines', 'HDR Bloom & Neon', 'Cel-Shaded', 'Retro CRT Curved'] as const).map((shader) => (
                <button
                  key={shader}
                  onClick={() => handleChange('shaderEffect', shader)}
                  className={`p-3 rounded-xl border text-xs font-bold text-center transition ${graphics.shaderEffect === shader ? 'bg-purple-500/20 border-purple-500 text-purple-300 shadow' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'}`}
                >
                  {shader}
                </button>
              ))}
            </div>
          </div>

          {/* Texture Filtering */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
              <Cpu className="w-4 h-4" /> Texture Filtering & xBRZ
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(['Nearest', 'Linear', 'xBRZ High Quality', 'Anisotropic 16x'] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => handleChange('textureFiltering', filter)}
                  className={`p-3 rounded-xl border text-xs font-bold text-center transition ${graphics.textureFiltering === filter ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'}`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          {/* FPS Limit */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">FPS Refresh Rate Limit</label>
            <div className="grid grid-cols-3 gap-2">
              {(['60 FPS (Standard)', '120 FPS High Refresh', 'Uncapped (Ultra)'] as const).map((fps) => (
                <button
                  key={fps}
                  onClick={() => handleChange('fpsLimit', fps)}
                  className={`p-3 rounded-xl border text-xs font-bold text-center transition ${graphics.fpsLimit === fps ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'}`}
                >
                  {fps}
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-zinc-950 border-t border-zinc-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-purple-600 hover:opacity-90 text-zinc-950 font-bold rounded-xl text-xs shadow-lg transition"
          >
            Apply & Save Settings
          </button>
        </div>

      </div>
    </div>
  );
};
