import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.adetunbiemmanuel.xplayer',
  appName: 'XPLAYER',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#05070b'
  }
};

export default config;
